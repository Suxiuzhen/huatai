import json
import time
import requests
import os
from .gen_yangli_word import gen_yangli_main
# from .gen_yangli_word_kpmg import gen_yangli_main_kpmg
from .gen_yangli_word_KPMG_new import gen_yangli_main_kpmg
import configparser

# rela_path=os.path.split(os.path.realpath(__file__))[0]
# father_path=os.path.split(rela_path)[0]
# sys.path.append(father_path)

import logging

logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)
handler = logging.FileHandler("table_name_log.txt")
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

config = configparser.ConfigParser()
config_file_path = "word2xlsConfig.cfg"
config.read(config_file_path, encoding='utf8')

HOST = config['tNameServer']['HOST']
PORT = config['tNameServer']['PORT']
url_template = config['tNameServer']['url_template']
dingqi_bianma = ['900068010301','90006801030101','90006801030103','90006801030105','90006801030107']
abs_bianma = ['900068020203']
zhaogu_bianma = ['900068010101','900068010103']
zhaiquan_bianma = ['900068020201']
shenji_bianma = ['90006801030109','900068020202','900068020204']


def table_name_main(csv_path, df_path, file_type):
    wenjian_id = os.path.split(csv_path)[1].replace('_content.csv', '')

    # 1.获取需要判断表名的前五行
    start_time = time.time()
    text_all = gen_yangli_main_kpmg(csv_path, df_path)

    if not os.path.exists('temp_content'):
        os.mkdir('temp_content')
    f_temp = open('temp_content/%s_5sent.txt' % wenjian_id, 'w', encoding='utf-8')
    f_temp.write(text_all)
    f_temp.close()

    # 2.请求分类server，生成表名
    table_name_dict = {}
    for line in text_all.split('\n'):
        if line == '':
            continue
        biao_id = line.split('\t')[0]
        content = '\t'.join(line.split('\t')[1:])
        biaoming = ''

        if (file_type in shenji_bianma) or (file_type in dingqi_bianma): # 审计报告
            PORT = config['tNameServer']['PORT_audit']

        elif file_type in zhaiquan_bianma:
            PORT = config['tNameServer']['PORT_zhaiquan']

        else:
            PORT = config['tNameServer']['PORT']

        get_table_name_url = url_template.format(HOST=HOST, PORT=PORT)
        url = get_table_name_url
        # url = "http://192.168.1.133:8828/biaoming"
        post_params = {}
        post_params['biao_id'] = str(biao_id)
        post_params['wenjian_id'] = str(wenjian_id)
        post_params['data'] = [{'content': content}]
        r = requests.post(url, data=json.dumps(post_params))
        #print(r.json())
        if r.json()['err'] == 0:
            biaoming_res = r.json()['biaoming_result']['biaoming']
            if biaoming_res:
                biaoming = biaoming_res[0]
            else:
                biaoming = '其他'
            table_name_dict[biao_id] = biaoming
            # logger.info('[table_id] %s [biaoming] %s' % (biao_id,biaoming))
        else:
            logger.error("biaoming_server error, please check!")
            raise Exception("biaoming_server error, please check!")

    end_time = time.time()
    logger.info('[get_biaoming_time] %.0fs' % (end_time - start_time))
    f = open('temp_content/%s_name.txt' % wenjian_id, 'w', encoding='utf-8')
    for i, j in table_name_dict.items():
        f.write('%s\t%s\n' % (i, j))
    f.close()
    return table_name_dict


if __name__ == '__main__':
    # csv_path = sys.argv[1]
    csv_path = '多伦科技招股意向书_save.csv'
    df_path = '多伦科技招股意向书._data_frame.csv'
    table_name_main(csv_path, df_path)
