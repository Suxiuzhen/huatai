# -*- coding: utf-8 -*-
import pandas as pd

def gen_yangli_main_kpmg(csv_path):
    df = pd.read_csv(csv_path)
    df_list = [(index,row) for index,row in df.iterrows()]
    #table_list = []
    text_all = ''
    for index,row in df_list:
        is_table = int(row['is_table'])
        content = str(row['content'])
        #level = row['level']
        if is_table == 1:
            biao_id = content
            #table_list.append(biao_id)
            iii = 0
            count = 0
            content_list = []
            while True:
                if count == 5:
                    break
                try:
                    pre_is_table = int(df_list[index-1-iii][1]['is_table'])
                    pre_content = df_list[index-1-iii][1]['content']
                except:
                    break
                if pre_is_table == 0:
                    count += 1
                else:
                    pre_content = '<table>'
                pre_content = pre_content.replace('\t','')
                pre_content = pre_content.replace('\n','')
                content_list.insert(0,pre_content.strip())
                iii += 1
            text_all += '%s\t%s\n' % (biao_id, '\001'.join(content_list))
    return text_all

if __name__ == '__main__':
    import sys
    csv_path = sys.argv[1]
    gen_yangli_main_kpmg(csv_path)
