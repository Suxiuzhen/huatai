# -*- coding: utf-8 -*-
import pandas as pd
import glob
import os
import re
import traceback


# 必须取5行
# 所有的word版本 都走这个处理
def gen_yangli_main_kpmg(csv_path, df_path):
    try:
        df = pd.read_csv(csv_path, encoding='utf-8') #['is_table', 'content', 'level']
    except:
        print('Read Data Error!')
    chart_df = pd.read_csv(df_path) #['is_table', 'content', 'level', 'Artificial_tablename']
    df_list = [(index, row) for index, row in df.iterrows()]
    text_all = ''
    min_level = min(df['level'])
    # levels_list = list(set(df['level']))
    # print(levels_list)
    # print('min_level =', min_level)
    for index, row in df_list:
        is_table = int(row['is_table'])
        content = str(row['content'])
        if is_table == 1:
            biao_id = content
            # print(biao_id)
            count = 0
            level_list = [] #标题level放进去（不是正文）
            content_list = []
            content_index = []
            flag_list = []
            # 所有表格取前5行文字，如果中间有表格，用<table>替代，<table>不计数
            for text_id in reversed(range(index)):
                try:
                    pre_is_table = int(df_list[text_id][1]['is_table'])
                    pre_content = df_list[text_id][1]['content']
                    pre_content = pre_content.replace('\t', '')
                    pre_content = pre_content.replace('\n', '')
                    pre_content = pre_content.replace(' ', '')
                    pre_level = int(df_list[text_id][1]['level'])
                except:
                    break

                if count == 5:
                    break

                if not pre_is_table == 0:  # 如果表且中间没有标题
                    pre_content = '<table>'
                    content_list.insert(0, pre_content)
                    content_index.insert(0, text_id)

                elif pre_level == 10:
                    content_list.insert(0, pre_content)
                    content_index.insert(0, text_id)
                    count += 1

                elif len(level_list) == 0:
                    level_list.append(pre_level)
                    content_list.insert(0, '<flag>' + pre_content + '</flag>')
                    content_index.insert(0, text_id)
                    count += 1

                elif len(level_list) and pre_level < level_list[-1]:
                    level_list.append(pre_level)
                    content_list.insert(0, '<flag>' + pre_content + '</flag>')
                    content_index.insert(0, text_id)
                    count += 1

                elif pre_level == min_level:
                    level_list.append(pre_level)
                    content_list.insert(0, '<flag>' + pre_content + '</flag>')
                    content_index.insert(0, text_id)
                    count += 1

            # 判断前5行中是否包含最大的标题，如果包含，跳过以下处理
            # 判断前5行中标题行是否大于3个，如果是，跳过以下处理
            # 如果不满足上述条件，往上找标题加入，剔除多余的行，确保文字行只有5行
            flag_dict = {}
            if len(level_list) and min(level_list) == min_level:
                pass
            elif len(level_list) >= 3:
                pass
            else:
                if content_index != []:
                    start_index = min(content_index)
                    for id in reversed(range(start_index)):
                        try:
                            pre_content = df_list[id][1]['content']
                            pre_content = pre_content.replace('\t', '')
                            pre_content = pre_content.replace('\n', '')
                            pre_content = pre_content.replace(' ', '')
                            pre_level = int(df_list[id][1]['level'])
                        except:
                            break

                        if len(level_list) and level_list[-1] == min_level:
                            break
                        elif len(level_list) and pre_level >= level_list[-1]:
                            continue
                        elif len(level_list) >= 3:
                            break
                        elif pre_level != 10:
                            level_list.append(pre_level)
                            flag_dict[id] = pre_level
                            content_list.insert(0, '<flag>' + pre_content.strip() + '</flag>')
                            content_index.insert(0, id)
                            count += 1
            # 如果后加标题行的数量>0,则剔除多余的行
            if len(flag_dict):
                dict_len = len(flag_dict)
                for i in reversed(range(dict_len)):
                    pop_index = dict_len + i
                    while re.search(r'(flag)|(table)', content_list[pop_index]):
                        pop_index = pop_index + 1
                    # print('pop', pop_index)
                    content_list.pop(pop_index)
                    content_index.pop(pop_index)

            # print(len(content_list))
            # print(content_list)

            content_list_final = [str(val)[-100:]if len(str(val))>100 else val for val in content_list]
            content_all = '\001'.join(content_list_final)
            # 如果content>500 取后面的500个字
            if len(content_all) > 500:
                content_all=content_all[-500:]
            str_raw = '\001'.join(flag_list)+content_all
            if index == 0:
                str_raw = ''
            # 表内第一列科目内容：
            table_num = int(biao_id.replace('TAB', ''))
            chart_df_one = chart_df[chart_df['page_num'] == table_num]
            in_table_num = list(set(list(chart_df_one['table_num'])))
            # print('in_table_num =',in_table_num)
            first_cell_list = []
            for in_table_index in in_table_num:
                first_cell_df = chart_df_one[(chart_df_one['cell_llx']==0)&(chart_df_one['table_num']==in_table_index)]
                first_cell_list += [str(i)[:20] for i in list(first_cell_df['word_text'])]

            cell_str = '\001'.join([str(i) for i in first_cell_list[:8]])
            text_all += '%s\t%s\t%s\n' % (biao_id, str_raw, cell_str)
            # name = csv_path.split('\t')[-1]
            # text_all += '%s\t%s\t%s\t%s\n' % (name, biao_id, str_raw, cell_str)
        # print(text_all)
    return text_all


def sub_TAB_with_table_name(text_all,save_df):
    def get_map(save_df):
        tab_map = {}
        save_df_filter = save_df[save_df['is_table'] == 1]
        save_df_filter = save_df_filter[save_df_filter['content'] != '']
        print(save_df_filter.columns)
        for i in save_df_filter.index:
            tab_map[save_df_filter.loc[i,'content']] = save_df_filter.loc[i,'Artificial_tablename']

        return tab_map
    tab_map = get_map(save_df)
    text_all_list = text_all.split('\n')
    text_all_1 = ''
    for text in text_all_list:
        tab = text.split('\t')[0]
        try:
            if re.search('TAB', tab):
                if tab_map[tab] == '其他':
                    tab_map[tab] = ''
                text = re.sub(tab,tab_map[tab],text)
                tab_map[tab]
                text_all_1 += text + '\n'
        except Exception as e:
            print(e)
    return text_all_1


if __name__ == '__main__':
    csv_paths = glob.glob('./ZHAOGU_WORD_20190518/*_content.csv')
    txt_path = './txt_zhaogu_word_20190520/'
    txt_path1 = './txt1_zhaogu_word_20190520/'
    if not os.path.exists(txt_path):
        os.mkdir(txt_path)
    if not os.path.exists(txt_path1):
        os.mkdir(txt_path1)

    for csv_path in csv_paths:
        try:
            name = csv_path.split('/')[-1].replace('_content.csv','')
            #print(name)
            df_path = './ZHAOGU_WORD_20190518/' + name + '_data_frame.csv'
            # print(csv_path, df_path)
            text_all = gen_yangli_main_kpmg(csv_path, df_path)
            save_path = './ZHAOGU_WORD_20190518/' + name + '_save.csv'
            save_df = pd.read_csv(save_path,encoding='utf8')

            with open(txt_path + '{name}.txt'.format(name = name),'w', encoding='utf8') as f:
                f.write(text_all)

            text_all = sub_TAB_with_table_name(text_all, save_df)
            with open(txt_path1 + '{name}.txt'.format(name = name),'w',encoding='utf8') as f:
                f.write(text_all)
        except Exception as e:
            print(name)
            print(traceback.format_exc())
