# -*- coding: utf-8 -*-
import pandas as pd

def gen_yangli_main(csv_path,df_path):
    df = pd.read_csv(csv_path)
    chart_df = pd.read_csv(df_path)
    df_list = [(index,row) for index,row in df.iterrows()]
    #table_list = []
    text_all = ''
    for index,row in df_list:
        is_table = int(row['is_table'])
        content = str(row['content'])
        #level = row['level']
        if is_table == 1:
            biao_id = content
            #table_list.append(biao_id)
            iii = 0
            count = 0
            level_list = []
            content_list = []
            flag_list = []
            while True:
                if count == 5 or len(level_list) == 3:
                    break
                try:
                    pre_is_table = int(df_list[index - 1 - iii][1]['is_table'])
                    pre_content = df_list[index - 1 - iii][1]['content']
                    pre_content = pre_content.replace('\t', '')
                    pre_content = pre_content.replace('\n', '')
                    pre_level = int(df_list[index - 1 - iii][1]['level'])
                except:
                    break
                if not pre_is_table == 0 and len(level_list) == 0:
                    pre_content = '<table>'
                    content_list.insert(0, pre_content.strip())
                if pre_level == 10:
                    if pre_is_table == 0 and len(level_list) == 0:
                        content_list.insert(0, pre_content.strip())
                        count += 1
                else:
                    if len(level_list):
                        # assert len(level_list) == 1
                        if level_list[-1] > pre_level:
                            level_list.append(pre_level)
                            content_list.insert(0, '<flag>' + pre_content.strip() + '</flag>')

                    else:
                        level_list.append(pre_level)
                        content_list.insert(0, '<flag>' + pre_content.strip() + '</flag>')

                # if '\t' in pre_content:
                #     print(pre_content)

                iii += 1

            content_list_final = []
            if len(content_list):
                # if len(content_list)>5:
                #     print(1)
                for cont_one in content_list:
                    cont_list = cont_one.split('。')
                    for cont_one_split in cont_list:
                        if cont_one_split:
                            content_list_final.append(cont_one_split)

            content_all = '\001'.join(content_list_final[-5:])
            if len(content_all) > 500:
                content_all=content_all[-500:]
            str_raw = '\001'.join(flag_list)+content_all
            if index == 0:
                str_raw = ''

            # 表内第一列科目内容：

            table_num = int(biao_id.replace('TAB',''))
            chart_df_one = chart_df[chart_df['page_num']==table_num]
            in_table_num = list(set(list(chart_df_one['table_num'])))
            first_cell_list = []
            for in_table_index in in_table_num:
                first_cell_df = chart_df_one[(chart_df_one['cell_llx']==0)&(chart_df_one['table_num']==in_table_index)]
                first_cell_list+=[str(i)[:20] for i in list(first_cell_df['word_text'])]
            cell_str='\001'.join([str(i) for i in first_cell_list[:8]])

            text_all += '%s\t%s\t%s\n' % (biao_id, str_raw, cell_str)

    return text_all

if __name__ == '__main__':
    import sys
    csv_path = sys.argv[1]
    gen_yangli_main(csv_path)
