#!/usr/bin/env python3  
# -*- coding: utf-8 -*-  
"""  
 @desc:  根据word中提取的文字层级进行表格名字的判断
 @author: Bingo Cai
"""
import re
import pandas as pd
import math
import json
from pattern_constant import TITLE_PATTERN, UNIT_PATTERN, NO_TITLE_PATTERN, DROP_TITLE_PATTERN, get_head_pattern
from pattern_constant import LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4

TITLE_1 = r'(^第一[章节])'  # 第一节
TITLE_2 = r'(^一、)'  # 一、释义
TITLE_3 = r'(^(一))'  # (一)主要会计数据

def title_len(title_lists):
    flag = False
    if len(title_lists) > 1:
        if re.search(UNIT_PATTERN, title_lists[0][0]):
            if len(title_lists) == 4:
                flag = True
        else:
            if len(title_lists) == 3:
                flag = True
        if flag:
            # 是否要去去掉最后一个句号结尾的
            last_tl = title_lists[len(title_lists) - 1]
            if last_tl[0].endswith("。"):
                title_lists.remove(last_tl)
            pass
        if len([tl for tl in title_lists if re.search(TITLE_PATTERN, tl[0])]) == 2:
            flag = True
    return flag


def fn_table_name(reversed_above_row_list):
    title_pattern = None
    title_lists = []
    dis_pre_line = False

    for i in range(5):
        try:
            text = reversed_above_row_list[i][1]

            if title_len(title_lists):
                break

            if len(text) == 0:
                continue

            if re.search(r'注[:：]', text):  # break or continue ?
                continue
            # word线路不需要这部分页眉页脚去除逻辑
            # if re.search(r'招股说明书|招股说明书（申报稿）|说明书|债券募集说明书|年度财务报表|资产支持专项计划|每期需要兑付的利息', text):
            #    continue
            if dis_pre_line:
                dis_pre_line = False
                '''
                七、主要控股参股公司分析                            <——字体大小有区别
                                                                 <——可以参考y轴高度的问题
                √ 适用 □ 不适用
                主要子公司及对公司净利润影响达 10%以上的参股公司情况
                '''
                if not re.search(TITLE_PATTERN, text):
                    continue
            # 例子
            # 公司是否需要遵守特殊行业的披露要求
            # 否
            if len(text) == 1:
                dis_pre_line = True
                continue

            zw_text = re.sub(r'[^\u4e00-\u9fa5]+', '', text)
            if "适用不适用" == zw_text or "不适用适用" == zw_text or "是否" == zw_text or "否是" == zw_text:
                if len([tl for tl in title_lists if not re.search(UNIT_PATTERN, tl[0])]) > 0:
                    if len(reversed_above_row_list) > i + 1:
                        dis_pre_line = True
                continue

            # 一定不在标题里面的关键字
            if re.search(NO_TITLE_PATTERN, text):
                continue

            # 排除无关的日期
            if re.search(r'(^\d{2,4}年\d{1,2}月\d{1,2}日[至\—]\d{2,4}年\d{1,2}月\d{1,2}日$)|'
                         r'(^\d{2,4}年[\S\s]*月$)|(^\d{2,4}年度货币单位：人民币元)', text):
                continue

            # if fsize > pre_fsize and 0 < len([tl for tl in title_lists if not re.search(UNIT_PATTERN, tl[0])]) < 2:
            #     continue

            if (text.endswith("。") and len(title_lists) > 0 and title_lists[len(title_lists) - 1][0].endswith("。")):
                # docx下该条件省略，必须要结合字体大小才能跳过
                # (len([tl for tl in title_lists if not re.search(UNIT_PATTERN, tl[0])]) > 1)
                break
            if title_pattern is not None and re.search(TITLE_PATTERN,
                                                       text) and title_pattern == get_head_pattern(text):
                break
            # if len(re.findall(r'[\u4e00-\u9fa5][ ]*[：:][ ]*[\u4e00-\u9fa5]', text)) > 1 and not re.search(UNIT_PATTERN,
            #                                                                                               text):
            #     continue

            title_lists.append((text,))
            if title_pattern is None and re.search(TITLE_PATTERN, text):
                title_pattern = get_head_pattern(text)

            if re.search(LEVEL_1,text):
                break
        except:
            # 如果层级不够5句跳出
            pass
    return title_lists


def fn_first_title(dlist):
    if dlist is not None and len(dlist) > 1:
        if len([tl for tl in dlist if len(tl) > 0 and re.search(TITLE_PATTERN, re.sub(r'\s+', '', tl[0]))]) == 2:
            last_title = dlist[len(dlist) - 1][0]
            if last_title is not None:
                pattern = get_head_pattern(dlist[len(dlist) - 2][0])
                if pattern is not None:
                    return dlist[len(dlist) - 1][0], pattern
                else:
                    return dlist[len(dlist) - 1][0], None

    return None, None


def repair_d1(table_name_dict, year, table_df):
    passage_dict = {}
    last_name = []
    fisrt_title = None

    # 对字典进行排序，后面操作依赖顺序
    table_name_dict = sorted(table_name_dict.items(), key=lambda v: int(v[0][3:]))

    for k, text_lists in table_name_dict:
        if text_lists is None:
            text_lists = []
        text_lists = [list(tlk) for tlk in text_lists]
        unit = None
        table_name = None
        remark = None
        # page_num = int(k[0:k.rfind("_")])
        page_num = None
        remove_text_lists = []

        for tl in text_lists:
            now_tl = tl[0]
            if len(tl) == 0:
                continue

            # 如果单位找到，则不需要寻找
            if not unit:
                # 处理掉单位中混合的编制单位等其他内容
                drop_res = re.search(DROP_TITLE_PATTERN, tl[0])
                if drop_res:
                    drop_text = drop_res.group(0)
                    tl[0] = tl[0].replace(drop_text, "")

                unit_res = re.search(UNIT_PATTERN, tl[0])

                if unit_res:
                    unit = unit_res.group()
                    tl0 = now_tl.replace(unit_res.group(), "")
                    if len(tl0) < 5:
                        remove_text_lists.append(tl)
                        continue
                    else:
                        now_tl = tl0

        for rtl in remove_text_lists:
            if rtl in text_lists:
                text_lists.remove(rtl)

        table_name = "&&".join([t[0] for t in text_lists if len(t) > 0])

        if table_name != "" and len(table_name.split("&&")) == 1 and \
                not re.search(r'[:。：]$', table_name) and \
                last_name is not None and len(last_name) > 0 and \
                (len(last_name[0].split("&&")) > 1) and (
                remark is None or remark == ""):
            pre_table_name = last_name[0]
            if fisrt_title is not None:
                pre_table_name = pre_table_name.replace(("&&" + fisrt_title[0]), "")
            last_name0s = pre_table_name.split("&&")
            if len(last_name0s) > 1:
                last_name0s_pattern = get_head_pattern(last_name0s[len(last_name0s) - 2])
                table_name_pattern = get_head_pattern(table_name)
                if last_name0s_pattern == table_name_pattern:
                    table_name = table_name + "&&" + last_name0s[len(last_name0s) - 1]

        if (remark is None or remark == "") and len(text_lists) == 1 and table_name is not None and re.search(
                r'&&\d{4}\s*年[度]*[\S\s]{0,6}\s*&&', "&&" + table_name + "&&"):
            if last_name and len(last_name) > 2:
                for l in last_name[0].split("&&"):
                    if not re.search(r'&&\d{4}\s*年[度]*[\S\s]{0,6}\s*&&', "&&" + l + "&&"):
                        table_name = table_name + "&&" + l
                        break
                remark = last_name[2]

        # if fisrt_title is not None:
        #     if page_num - fisrt_title[1] > 3:
        #         fisrt_title = None

        tmp_fisrt_title, first_pattern = fn_first_title(text_lists)
        if tmp_fisrt_title:
            fisrt_title = (tmp_fisrt_title, page_num, first_pattern)

        if fisrt_title is not None and table_name and fisrt_title[
            0] not in table_name and text_lists is not None and len(
            text_lists) > 0:
            if (re.search(r'^[一二三四五六七八九十]', text_lists[len(text_lists) - 1][0]) and \
                re.search(r'^[一二三四五六七八九十]', fisrt_title[0])) or (
                    re.search(r'^[0-9]', text_lists[len(text_lists) - 1][0]) and \
                    re.search(r'^[0-9]', fisrt_title[0])) or (
                    re.search(r'^\s*（\s*[0-9]', text_lists[len(text_lists) - 1][0]) and \
                    re.search(r'^\s*（\s*[0-9]', fisrt_title[0])) or \
                    (re.search(r'^\s*（\s*[一二三四五六七八九十]', text_lists[len(text_lists) - 1][0]) and \
                     re.search(r'^\s*（\s*[一二三四五六七八九十]', fisrt_title[0])):
                fisrt_title = None
            elif table_name == "" or remark == "" or remark is None or table_name is None:
                if get_head_pattern(table_name) == fisrt_title[2] and '续上表' not in table_name:
                    table_name = table_name + "&&" + fisrt_title[0]

        if (table_name is None or table_name == "") and remark is not None:
            table_name = remark
            remark = ""
            if last_name:
                if len(last_name) > 0:
                    last_name[0] = table_name
                if len(last_name) > 2:
                    last_name[2] = remark
        if text_lists is not None and last_name is not None and len(text_lists) == 0 and len(last_name) > 0 and (
                table_name is None or table_name == ""):
            table_name = last_name[0]
            if len(last_name) > 1 and unit is None:
                unit = last_name[1]
            if len(last_name) > 2:
                remark = last_name[2]
        # if re.search(r'续\S{0,2}\s*&&', '&&'.join(table_name.split("&&"))) and len(last_name) > 0:
        #     table_name = last_name[0]
        last_name = []
        last_name.append(table_name)
        last_name.append(unit)
        last_name.append(remark)

        tb_dic = {}
        tb_dic["table_name"] = "&&".join([t for t in table_name.split("&&") if not re.search(r'第[\s\d]*页', t)])
        tb_dic["unit"] = unit
        tb_dic["remark"] = remark
        tb_dic["year"] = year
        passage_dict[k] = tb_dic

        # ##### 修改表格相关的list
        # dlists = d[k]
        # dklists = [dl + [table_name, unit, remark] for dl in dlists]
        # d[k] = dklists
        # # d1[k] = [table_name, unit, remark]

    # 对上方构造的pass_dict进行处理，添加没有抽取出来的 母公司 和 合并
    tablename_df = covert_tablename_to_csv(passage_dict)
    new_tablename_df = add_table_name(table_df, tablename_df)
    passage_dict = new_tablename_df.to_dict('index')
    return passage_dict


def get_table_df(heading_data_df):
    column_names = ["is_table", "text", "level"]
    if len(heading_data_df.columns) == 5:
        column_names.append("content_id")
        column_names.append("outline_details")
    # TODO to delete outline
    if len(heading_data_df.columns) == 6:
        column_names.append("content_id")
        column_names.append("outline_details")
        column_names.append('flag_copy')
    heading_data_df.columns = column_names
    return heading_data_df


def get_report_year(heading_data_df, report_type):
    texts = "".join(heading_data_df['text'].tolist())
    report_year_list = re.findall(r'(\d{4})', texts)

    if report_year_list:
        report_year = report_year_list[0]
        # report_year = max(set(report_year_list), key=report_year_list.count)
        if report_year:
            # 一季度报告
            if report_type == "9000680001001":
                return str(report_year) + "年03月31日"
            # 半年度报告
            elif report_type == "9000680001003":
                return str(report_year) + "年06月30日"
            # 三季度报告
            elif report_type == "9000680001004":
                return str(report_year) + "年09年30日"
            # 年度报告 9000680001005 或者其他
            else:
                return str(report_year) + "年"
    else:
        # 取不到则给2000年,防止报错
        report_year = "2000年"
        return report_year


def split_table_range(df):
    table_dict = {}
    above_list = []
    for index, row in df.iterrows():
        # 这个地方需要修改
        if row["is_table"] == 0:
            split_row_list = re.split('[。?!]', row["text"])
            for i in range(len(split_row_list)):
                new_row = pd.Series([row["is_table"], split_row_list[i], row["level"]])
                above_list.append(new_row)
        else:
            table_dict[row["text"]] = above_list
            above_list = []
    return table_dict


def extra_table_name(table_dict):
    table_name_dict = {}

    for k, v in table_dict.items():
        reversed_above_row_list = v[::-1]
        title_lists = fn_table_name(reversed_above_row_list)
        table_name_dict[k] = title_lists
    return table_name_dict


def covert_tablename_to_csv(passage_dict):
    df = pd.DataFrame.from_dict(passage_dict).T
    return df



flag_list = [LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4]


def get_chapter_range(table_df, chapter_pattern):
    company_pattern = None
    company_tag = False  # 确保下一行正则才开始生效
    chapter_list = []
    chapter_head = None
    for index, row in table_df.iterrows():
        if re.search(chapter_pattern, row["text"]):
            for v in flag_list:
                if re.search(v, row["text"]):
                    chapter_head = re.search(v, row["text"]).group(0)
                    company_pattern = v
        # 找到项目编号的正则样式
        if company_pattern and chapter_head:
            if company_tag:
                if re.search(company_pattern, row["text"]):
                    match_string = re.search(company_pattern, row["text"]).group(0)
                    if match_string and match_string != chapter_head:
                        break
                else:
                    if re.search(r"TAB", row["text"]):
                        chapter_list.append(row["text"])
            company_tag = True
    return chapter_list


# def add_table_name(table_df, tablename_df):
#     father_list = get_chapter_range(table_df, r"母公司财务报表主要项目注释")
#     total_list = get_chapter_range(table_df, r"合并财务报表项目注释")
#     tablename_df.loc[father_list, 'table_name'] = tablename_df.loc[father_list, 'table_name'] + "&&母公司财务报表主要项目注释"
#     tablename_df.loc[total_list, 'table_name'] = tablename_df.loc[total_list, 'table_name'] + "&&合并财务报表项目注释"
#     return tablename_df


def add_one_table_name(table_df, tablename_df, father_item, total_item):
    father_list = get_chapter_range(table_df, father_item)
    total_list = get_chapter_range(table_df, total_item)
    tablename_df.loc[father_list, 'table_name'] = tablename_df.loc[father_list, 'table_name'] + "&&" + father_item
    tablename_df.loc[total_list, 'table_name'] = tablename_df.loc[total_list, 'table_name'] + "&&" + total_item
    return tablename_df


def add_table_name(table_df, tablename_df):
    add_table_name_list = [
        {"father": "母公司财务报表主要项目注释", "total": "合并财务报表项目注释"},
        {"father": "母公司报表口径分析", "total": "合并报表口径分析"}
    ]
    for item in add_table_name_list:
        tablename_df = add_one_table_name(table_df, tablename_df, item["father"], item["total"])
    return tablename_df


if __name__ == '__main__':
    csv_path = '/home/cbb/Desktop/git_repo/new_get_table_kpmg/files/8264728622269440_content.csv'
    report_type = "9000680001005"
    import pandas as pd

    heading_data_list = pd.read_csv(csv_path)
    table_df = get_table_df(heading_data_list)
    year = get_report_year(table_df, report_type)
    # 切分表格范围
    table_dict = split_table_range(table_df)
    table_name_dict = extra_table_name(table_dict)
    # 抽取表名，修正表名
    passage_dict = repair_d1(table_name_dict, year, table_df)

    # # 输入表名 df
    # td_df = covert_tablename_to_csv(passage_dict)
    # td_df.to_csv("./tb_name.csv")
