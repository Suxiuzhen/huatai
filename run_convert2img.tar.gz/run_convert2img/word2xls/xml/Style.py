# -*- coding: utf-8 -*-
# @Time    : 2018/11/16
# @Author  : jxjiang

from ..style_enum import Normal_level

class Style(object):
    def __init__(self):
        self.name = None
        self.styleId = None
        self.type = 'paragraph'
        self.outlineLvl = Normal_level
        self.basedOn = None