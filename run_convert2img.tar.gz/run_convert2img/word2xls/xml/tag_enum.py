# -*- coding: utf-8 -*-
# @Time    : 2018/10/31
# @Author  : jxjiang

prefix = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

class TagEnum_Table():
    tbl = prefix + 'tbl'
    tblPr = prefix + 'tblPr'
    tblBorders = prefix + 'tblBorders'


class TagEnum_Row():
    tr = prefix + 'tr'
    trPr = prefix + 'trPr'

    tblBorders = prefix + 'tblBorders'

class TagEnum_Cell():
    tc = prefix + 'tc'
    tcPr = prefix + 'tcPr'
    gridSpan = prefix + 'gridSpan'
    gridSpan_val = prefix + 'val'
    vMerge = prefix + 'vMerge'
    vMerge_value_continue = 'continue'
    vMerge_value_restart = 'restart'

    w = prefix + 'w'
    p = prefix + 'p'
    r = prefix + 'r'
    t = prefix + 't'


TAGENUM_Table = TagEnum_Table()
TAGENUM_Row = TagEnum_Row()
TAGENUM_Cell = TagEnum_Cell()
