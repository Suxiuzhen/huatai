# -*- coding: utf-8 -*-
# @Time    : 2018/10/31
# @Author  : jxjiang

from lxml import etree as ET
from .tag_enum import *
from .Style import Style
from ..style_enum import Normal_level, word_Normal_level
# from ..merge_info import MergeInfo
import traceback
import os
import shutil
import zipfile

class DocxParser(object):
    prefix = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    tag_list = ["top", "start", "bottom", "end", "insideH", "insideV"]

    def __init__(self, file_path, output_root):
        self.file_path = file_path
        if self.file_path.endswith('.docx'):
            self.file_path = self.docx2xml(file_path, output_root)
        self.tree = ET.parse(self.file_path)
        self.outline_dict = None

    def docx2xml(self, docx_path, output_root=None):
        if output_root:
            file_name_without_ext = os.path.splitext(os.path.split(docx_path)[1])[0]
            work_dir = os.path.join(output_root, file_name_without_ext)
        else:
            work_dir = os.path.splitext(docx_path)[0]
        work_dir = os.path.join(work_dir, 'xml')
        if not os.path.exists(work_dir):
            os.makedirs(work_dir)

        file_name = os.path.splitext(os.path.split(docx_path)[1])[0]

        WORKING_DIR = work_dir
        TEMP_ZIP = os.path.join(WORKING_DIR, file_name + ".zip")
        TEMP_FOLDER = os.path.join(WORKING_DIR, file_name)

        # remove old zip file or folder template
        if os.path.exists(TEMP_ZIP):
            os.remove(TEMP_ZIP)
        if os.path.exists(TEMP_FOLDER):
            shutil.rmtree(TEMP_FOLDER)

        # reformat template.docx's extension
        shutil.copy(docx_path, TEMP_ZIP)

        # unzip file zip to specific folder
        with zipfile.ZipFile(TEMP_ZIP, 'r') as z:
            z.extractall(TEMP_FOLDER)
        xml_path = os.path.join(TEMP_FOLDER, 'word', 'document.xml')
        return xml_path

    def close(self):
        return

    def extract_table(self, specific_table_index=None):
        tables_dict = {}
        merge_info_dict = {}

        for index, elem_tbl in enumerate(self.tree.iter(self.prefix + "tbl")):
            try:
                if specific_table_index:
                    if index not in specific_table_index:
                        continue
                table, merge_info_list = self.parsing_table(elem_tbl)
                tables_dict[index] = table
                merge_info_dict[index] = merge_info_list
            except Exception as e:
                print(e)
                print(traceback.clear_frames())
        return tables_dict


    def parsing_table(self, elem_tbl):
        bool_tblPr = False
        # for elem_tblPr in self.tree.iter(self.prefix + "tblPr"):
        #     bool_tblPr = True
        #
        #     iter_tblBorders = elem_tblPr.iter(self.prefix + "tblBorders")
        #     bool_tblBorder = False
        #     for t in iter_tblBorders:
        #         bool_tblBorder = True
        #
        #         elem_tblPr.remove(t)
        #     new_t = ET.Element(self.prefix + "tblBorders")

        rows_content_list = []
        merge_info_list = []
        for row_idx, elem_tr in enumerate(elem_tbl.iter(TAGENUM_Row.tr)):
            row_content, merge_info = self.parsing_row(elem_tr, row_idx)
            rows_content_list.append(row_content)
            merge_info_list.extend(merge_info)
        return rows_content_list, merge_info_list

    def parsing_row(self, elem_tr, cur_row_idx):
        row_content = []
        merge_info = []
        col_offset = 0

        for col_idx, elem_tc in enumerate(elem_tr.iter(TAGENUM_Cell.tc)):
            text = ''
            self.parsing_cell(elem_tc, cur_row_idx, col_offset)
        return row_content, merge_info


    def parsing_cell(self, elem_tc, cur_row_idx, cur_col_idx):
        text = ''
        span_num = 1
        for elem_tcPr in elem_tc.iter(TAGENUM_Cell.tcPr):
            for grid_span in elem_tcPr.iter(TAGENUM_Cell.gridSpan):
                if grid_span is not None:
                    span_num = grid_span.get(TAGENUM_Cell.gridSpan_val)
                    if span_num:
                        print(span_num)
        # vMerge
        for elem_p in elem_tc.iter(TAGENUM_Cell.p):
            for elem_r in elem_p.iter(TAGENUM_Cell.r):
                for elem_t in elem_r.iter(TAGENUM_Cell.t):
                    text += elem_t.text
        print(text)
        cell = [text] * span_num
        merge_info = MergeInfo(cur_col_idx, cur_col_idx+span_num-1, cur_row_idx, cur_row_idx)

    def extract_outline(self, style_dict):
        self.outline_dict = {}
        outline_list = []
        for body in self.tree.getroot():
            if body.tag == self.prefix + 'body':
                for index, elem_block in enumerate(body):
                    if elem_block.tag == self.prefix + 'p':
                        parsing_res = self.parsing_paragraph(elem_block, style_dict)
                        if parsing_res is None:
                            continue
                        outlineLvl, content = parsing_res
                        if outlineLvl == word_Normal_level:
                            continue

                        new_outline = {}
                        new_outline['content'] = content
                        new_outline['level'] = outlineLvl
                        outline_list.append(new_outline)

        return self.outline_dict, outline_list

    def parsing_paragraph(self, elem_paragraph, style_dict):

        outlineLvl = self.parsing_paragraph_property(elem_paragraph, style_dict)
        if outlineLvl is not None:
            total_text_list = []
            for elem_r in elem_paragraph.iter(self.prefix + 'r'):
                for elem_text in elem_r.iter(self.prefix + 't'):
                    cur_text = elem_text.text
                    if cur_text is not None:
                        total_text_list.append(cur_text)

            text_key = ''.join(total_text_list)
            text_key = text_key.strip()

            if len(text_key) > 0:
                if self.outline_dict.get(text_key) is not None \
                        and self.outline_dict.get(text_key) != word_Normal_level:
                    print('error. Duplicate outline conten found. text={}'.format(text_key))
                self.outline_dict[text_key] = outlineLvl
                return outlineLvl, text_key
        return None

    def parsing_paragraph_property(self, elem_paragraph, style_dict):
        for elem_pPr in elem_paragraph.iter(self.prefix + 'pPr'):
            for elem_outlineLvl in elem_pPr.iter(self.prefix + 'outlineLvl'):
                outlineLvl = elem_outlineLvl.get(self.prefix + 'val')
                if outlineLvl:
                    return outlineLvl
            for elem in elem_pPr:
                if elem.tag == self.prefix + 'pStyle':
                    style_id = elem.get(self.prefix + 'val')
                    style = style_dict.get(style_id)
                    if int(style.outlineLvl) < int(word_Normal_level):
                        return style.outlineLvl


    def extract_style(self):
        style_path = os.path.join(os.path.split(self.file_path)[0], 'styles.xml')
        style_dict = {}
        if not os.path.exists(style_path):
            return style_dict
        style_tree_root = ET.parse(style_path)
        for elem_style in style_tree_root.iter(self.prefix + "style"):
            cur_style = self.parsing_style(elem_style)
            style_dict[cur_style.styleId] = cur_style

        self.trace_style_outlineLvl(style_dict)
        return style_dict

    def trace_style_outlineLvl(self, style_dict):
        for _, cur_style in style_dict.items():
            if cur_style.outlineLvl == Normal_level:
                cur_style.outlineLvl = self.get_basedOn_outlineLvl(style_dict, cur_style.basedOn)

    def get_basedOn_outlineLvl(self, style_dict, basedOn_id):
        '''递归查找大纲级别'''
        if basedOn_id is None:
            return Normal_level
        basedOn_style = style_dict.get(basedOn_id)
        if basedOn_style is None:
            return Normal_level
        if basedOn_style.outlineLvl == Normal_level:
            return self.get_basedOn_outlineLvl(style_dict, basedOn_style.basedOn)
        else:
            return basedOn_style.outlineLvl

    def parsing_style(self, elem_style):
        cur_style = Style()
        styleId = elem_style.get(self.prefix + "styleId")
        cur_style.styleId = styleId
        styleType = elem_style.get(self.prefix + "type")
        if styleType is not None:
            cur_style.type = styleType

        for elem_name in elem_style.iter(self.prefix + "name"):
            name = elem_name.get(self.prefix + 'val')
            if name is not None:
                cur_style.name = name
                break

        for elem_name in elem_style.iter(self.prefix + "basedOn"):
            basedOn = elem_name.get(self.prefix + 'val')
            if basedOn is not None:
                cur_style.basedOn = basedOn
                break

        for elem_pPr in elem_style.iter(self.prefix + "pPr"):
            for elem_outlineLvl in elem_pPr.iter(self.prefix + "outlineLvl"):
                outlineLvl = elem_outlineLvl.get(self.prefix + 'val')
                if outlineLvl is not None:
                    cur_style.outlineLvl = outlineLvl
                    break
        return cur_style


if __name__=='__main__':
    # file_path = '/Users/johnjx/Documents/myGit/docx_table_extract/word2xls/removeHead/002422有问题/word/document.xml'
    # dparser = DocxParser(file_path)
    # dparser.extract_table()

    file_path = '/Users/johnjx/Documents/myGit/docx_table_extract/word2xls/removeHead/1-1 御家汇股份有限公司首次公开发行股票并上市招股说明书0329【上报】(1).docx'
    dparser = DocxParser(file_path)
    dparser.extract_style()