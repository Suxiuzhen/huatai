# -*- coding: utf-8 -*-
# @Time    : 2018/10/26
# @Author  : jxjiang

import pandas as pd


def merge_corpus():
    file_name = 'ABC公司'
    docx_content_file = file_name + '_content.csv'
    real_table_name_file = file_name + '-mapping.xlsx'
    save_file = file_name + '_content_real.csv'
    real_table_name = pd.read_excel(real_table_name_file)
    docx_content = pd.read_csv(docx_content_file)

    table_index = 0
    docx_content_list = docx_content.values.tolist()
    for block_content in docx_content_list:
        if int(block_content[0]) == 1:
            real_name = real_table_name.loc[table_index]['real_name']
            if real_name == '':
                real_name = None
            block_content.append(real_name)
            table_index +=1
        else:
            block_content.append(None)
    column_names = ['is_table', 'content', 'level', 'table_name']
    df = pd.DataFrame(docx_content_list, columns=column_names)
    df.fillna('None', inplace=True)
    df.to_csv(save_file, index=False)

if __name__=='__main__':
    merge_corpus()