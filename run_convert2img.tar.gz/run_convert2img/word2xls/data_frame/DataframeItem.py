# -*- coding: utf-8 -*-
# @Time    : 2018/9/27
# @Author  : jxjiang

class DataframeItem(object):
    def __init__(self, table_name, cell_range_info, page, table_index, text, addition_info, cell_id):
        self.cell_id = cell_id
        self.page = page
        self.table_index = table_index
        self.cell_range_info = self.parsing_range(cell_range_info)
        self.text = text
        self.table_name = table_name
        if addition_info is not None:
            self.parsing_addition(addition_info)


    def parsing_range(self, range_info):
        xl_pixel, xr_pixel, yu_pixel, yd_pixel = range_info
        return [xl_pixel, xr_pixel, yd_pixel, yu_pixel]

    def parsing_addition(self, addition_info):
        self.unit = addition_info.get('unit')
        self.remark = addition_info.get('remark')
        self.report_year = addition_info.get('year')
        self.report_type = addition_info.get('report_type')


    def to_item(self):
        item = []
        item.append(self.page)
        item.append(self.table_index)
        item.extend(self.cell_range_info)
        item.append(self.text)
        item.append(self.table_name)
        item.append(self.unit)
        item.append(self.remark)
        item.append(self.report_year)
        item.append(self.report_type)
        item.append(self.cell_id)
        return item