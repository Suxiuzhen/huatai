# -*- coding: utf-8 -*-
'''
Created on 2018年11月1日

@author: zhuchenxi
'''
import getopt
import sys
from PIL import Image

def combine_jpg(input_list, output_path):
    #进行排序，保证接的图片顺序
    input_new_list = []
    if len(input_list) > 1:
        input_list_tuple = []
        for input in input_list:
            input_list_tuple.append((int(input.split(".")[-2].split("-")[-1]), input))
        input_new_list = [x[1] for x in sorted(input_list_tuple, key=lambda k:k[0])]
    else:
        input_new_list = input_list
    images = map(Image.open, input_new_list)
    images_list = [x for x in images]
    widths, heights = zip(*(i.size for i in images_list))
    
    max_width = max(widths)
    total_height = sum(heights)
    
    combine_mode = 'RGB'

    for im in images_list:
        if not im.mode == 'RGB':
            combine_mode = 'RGBA'
            break

    new_im = Image.new(combine_mode, (max_width, total_height))
    
    y_offset = 0
    for im in images_list:
        new_im.paste(im, (0,y_offset))
        y_offset += im.size[1]
    
    new_im.save(output_path)

def work(ff = sys.stdin, fout = sys.stdout):
    combine_jpg(["8264975695152128_120.png"], "b.png")
#     for line in ff:
#         line = line.rstrip("\n")
#         splits = line.split("\t")

def main(args):

    ff = sys.stdin
    fout = sys.stdout
    opts, args = getopt.getopt(args, "f:o:")
    for op, value in opts:
        if op == '-f':
            ff = open(value, 'r')
        if op == '-o':
            fout = open(value, 'w')
    work(ff, fout)
import time
if __name__ == '__main__':
    start = time.time()
    combine_jpg(["8309524142785536_183/8309524142785536_183-0.png", "8309524142785536_183/8309524142785536_183-1.png"], "c.png")
    print(time.time()-start)
    # main(sys.argv[1:])
